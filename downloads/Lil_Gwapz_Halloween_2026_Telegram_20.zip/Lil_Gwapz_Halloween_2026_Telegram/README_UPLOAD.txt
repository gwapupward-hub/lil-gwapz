LIL GWAPZ | HAUNTED GWAPZ 2026 — TELEGRAM STATIC STICKER PACK
20 official Halloween 2026 Lil Gwapz designs (10 male + 10 female).

STATUS: 20 production-ready WebP files. Telegram sticker set NOT YET published.

UPLOAD ON IPHONE:
1. Open Telegram, search for the verified @Stickers bot (https://t.me/Stickers).
2. Create a new static sticker pack in the bot. Use the title: Lil Gwapz | Haunted Gwapz 2026.
3. Upload every .webp from stickers/ as FILE/DOCUMENT rather than a compressed photo.
4. Associate each sticker with its emoji listed in telegram_manifest.json.
5. Use pack-icon-100.png as the thumbnail if the bot accepts a custom static thumbnail.
6. Publish and save the real t.me/addstickers/... URL. Do not guess this URL.

SPEC CHECK: 512x512 WebP with transparency; each file below 512 KB. Source artwork unchanged.
LICENSE: Free official personal reactions. No resale, redistribution as another pack,
commercial licensing, NFT use, or AI training. Copyright 2026 Tha GwapSpot.
